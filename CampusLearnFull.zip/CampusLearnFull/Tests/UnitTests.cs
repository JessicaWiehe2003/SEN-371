using Xunit;
using CampusLearn.Models;

namespace CampusLearn.Tests
{
    public class UnitTests
    {
        [Fact]
        public void Topic_Has_Title()
        {
            var t = new Topic { Title = "X", Description = "Y" };
            Assert.Equal("X", t.Title);
        }
    }
}
