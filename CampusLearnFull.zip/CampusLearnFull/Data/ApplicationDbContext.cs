using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CampusLearn.Models;

namespace CampusLearn.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) {}

        public DbSet<Topic> Topics => Set<Topic>();
        public DbSet<LearningMaterial> LearningMaterials => Set<LearningMaterial>();
        public DbSet<Comment> Comments => Set<Comment>();
    }
}
