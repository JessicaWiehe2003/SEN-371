using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Linq;
using CampusLearn.Data;
using CampusLearn.Models;

namespace CampusLearn.Controllers
{
    [Authorize]
    public class CommentsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        public CommentsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context; 
            _userManager = userManager;
        }

        public async Task<IActionResult> TopicComments(int topicId)
        {
            var topic = await _context.Topics.Include(t => t.Tutor).FirstOrDefaultAsync(t => t.Id == topicId);
            if (topic == null) return NotFound();
            var comments = await _context.Comments.Where(c => c.TopicId == topicId)
                .Include(c => c.User).OrderByDescending(c => c.CreatedAt).ToListAsync();
            ViewBag.Topic = topic;
            return View(comments);
        }

        [HttpPost]
        [Authorize] // must be logged in to post
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddComment(int topicId, string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                TempData["Error"] = "Please enter a comment.";
                return RedirectToAction("TopicComments", new { topicId });
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge(); // not logged in -> redirect to login

            try
            {
                _context.Comments.Add(new Comment
                {
                    Content = content,
                    TopicId = topicId,
                    UserId = user.Id
                });
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                TempData["Error"] = "Could not save comment: " + ex.Message;
            }

            return RedirectToAction("TopicComments", new { topicId });
        }
    }
}
