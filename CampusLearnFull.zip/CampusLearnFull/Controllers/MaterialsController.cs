using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System.IO;
using System;
using System.Linq;
using CampusLearn.Data;
using CampusLearn.Models;

namespace CampusLearn.Controllers
{
    [Authorize]
    public class MaterialsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;
        public MaterialsController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context; _env = env;
        }

        [Authorize(Roles = "Tutor")]
        public async Task<IActionResult> Upload(int topicId)
        {
            var topic = await _context.Topics.FindAsync(topicId);
            if (topic == null) return NotFound();
            ViewBag.TopicId = topicId;
            return View();
        }

        [Authorize(Roles = "Tutor")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upload(int topicId, IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                var uploads = Path.Combine(_env.WebRootPath, "uploads");
                Directory.CreateDirectory(uploads);
                var fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
                var path = Path.Combine(uploads, fileName);
                using (var stream = new FileStream(path, FileMode.Create))
                    await file.CopyToAsync(stream);

                _context.LearningMaterials.Add(new LearningMaterial
                {
                    FileName = file.FileName,
                    FilePath = "/uploads/" + fileName,
                    TopicId = topicId
                });
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(ViewByTopic), new { topicId });
            }
            ModelState.AddModelError("", "Please upload a valid file.");
            ViewBag.TopicId = topicId;
            return View();
        }

        public async Task<IActionResult> ViewByTopic(int topicId)
        {
            var topic = await _context.Topics.Include(t => t.Tutor).FirstOrDefaultAsync(t => t.Id == topicId);
            if (topic == null) return NotFound();
            var materials = await _context.LearningMaterials.Where(m => m.TopicId == topicId).ToListAsync();
            ViewBag.Topic = topic;
            return View(materials);
        }
    }
}
