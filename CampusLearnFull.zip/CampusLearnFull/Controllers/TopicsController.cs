using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using CampusLearn.Data;
using CampusLearn.Models;

namespace CampusLearn.Controllers
{
    [Authorize]
    public class TopicsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        public TopicsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context; _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var topics = await _context.Topics.Include(t => t.Tutor).ToListAsync();
            return View(topics);
        }

        [Authorize(Roles = "Tutor")]
        public IActionResult Create() => View();

        [Authorize(Roles = "Tutor")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Topic topic)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User);
                topic.TutorId = user?.Id;
                _context.Topics.Add(topic);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(topic);
        }

        public async Task<IActionResult> Details(int id)
        {
            var topic = await _context.Topics.Include(t => t.Tutor).FirstOrDefaultAsync(t => t.Id == id);
            if (topic == null) return NotFound();
            return View(topic);
        }
    }
}
