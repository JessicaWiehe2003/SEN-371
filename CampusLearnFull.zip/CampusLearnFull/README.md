# CampusLearn (Fixed)
ASP.NET Core MVC app (C#, .NET 6) with Identity, SQLite, Topics, Materials uploads, Comments, and REST APIs.

## Run
1. Open `CampusLearn.sln` or the folder in Visual Studio 2022+.
2. Press **F5**.
   - The app uses **SQLite** (`Data Source=campuslearn.db`).
   - On first run, the DB is created and roles **Student** and **Tutor** are seeded.

## HTTP Only (no HTTPS prompts)
- `applicationUrl` is HTTP-only in `Properties/launchSettings.json`.
- `UseHttpsRedirection()` and `UseHsts()` are commented in `Startup.cs`.

## Default Features
- Register/Login with role selection
- Tutors create topics, upload materials
- Students & tutors comment on topics
- REST endpoints under `/api/...`

