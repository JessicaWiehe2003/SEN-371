using Microsoft.AspNetCore.Identity;

namespace CampusLearn.Models
{
    public class ApplicationUser : IdentityUser
    {
        // extend with profile fields if needed
    }
}
