using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace CampusLearn.Models
{
    public class LearningMaterial
    {
        public int Id { get; set; }
        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
        public int TopicId { get; set; }

        [ForeignKey(nameof(TopicId))]
        public Topic? Topic { get; set; }
    }
}
