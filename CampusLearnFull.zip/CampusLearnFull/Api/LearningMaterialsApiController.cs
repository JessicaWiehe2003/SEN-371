using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using CampusLearn.Data;
using CampusLearn.Models;

namespace CampusLearn.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class LearningMaterialsApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public LearningMaterialsApiController(ApplicationDbContext context) { _context = context; }

        [HttpGet("topic/{topicId}")]
        public async Task<ActionResult<IEnumerable<LearningMaterial>>> GetByTopic(int topicId) =>
            await _context.LearningMaterials.Where(m => m.TopicId == topicId).ToListAsync();
    }
}
