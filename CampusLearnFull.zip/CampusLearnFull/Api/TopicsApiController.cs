using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using CampusLearn.Data;
using CampusLearn.Models;

namespace CampusLearn.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class TopicsApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public TopicsApiController(ApplicationDbContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Topic>>> Get() =>
            await _context.Topics.Include(t => t.Tutor).ToListAsync();

        [HttpGet("{id}")]
        public async Task<ActionResult<Topic>> Get(int id)
        {
            var topic = await _context.Topics.Include(t => t.Tutor).FirstOrDefaultAsync(t => t.Id == id);
            return topic == null ? NotFound() : topic;
        }
    }
}
