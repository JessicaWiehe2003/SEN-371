using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using CampusLearn.Data;
using CampusLearn.Models;

namespace CampusLearn.Api
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class CommentsApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public CommentsApiController(ApplicationDbContext context) { _context = context; }

        [HttpGet("topic/{topicId}")]
        public async Task<ActionResult<IEnumerable<Comment>>> GetByTopic(int topicId) =>
            await _context.Comments.Where(c => c.TopicId == topicId).Include(c => c.User)
                .OrderByDescending(c => c.CreatedAt).ToListAsync();
    }
}
